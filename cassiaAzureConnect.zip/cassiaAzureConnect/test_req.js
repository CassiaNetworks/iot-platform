﻿// Test request file
let EventSource = require('eventsource')

let apiService = require('./cassia/apiService')

let es = new EventSource('http://192.168.1.126/gap/nodes?event=1&active=0&filter_duplicates=1&mac=CC:1B:E0:E0:60:C8')

es.addEventListener('open', function (e) {
    console.log(e)
})

es.addEventListener('message', function (e) {
    console.log(e.data)
})
