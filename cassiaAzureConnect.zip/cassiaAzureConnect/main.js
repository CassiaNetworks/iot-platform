﻿/*
    Cassia Azure Connect
    Allows the Cassia Gateway to communicate with Azure IoTHub Device Twin
    
    Config:
    config/azure-config.json
    config/device-config.json
 */

// Load device & Azure Config
let DeviceConfig = require("./config/device-config.json"),
    AzureConfig = require("./config/azure-config.json")

// Load Azure Client
let iotClient = require("./config/azure-client")
    //iotRegistry = require("../config/azure-registry")

// Cassia API
let CassiaApiLocation = require('./cassia/cassia-location'),
    CassiaGapServices = require('./cassia/cassia-gap'),
    CassiaGattServices = require('./cassia/cassia-gatt')

// Load the Twin functions for connecting to Azure IoT hub and sending the device remote commands
// path = (Local Lib -> Azure Twin -> IoT Client on Device)
let DeviceTwin = require("./functions/device-twin"),
    AzureMessage = require('./functions/azure-message')
    TwinService = require('./twin/service'),
    TwinGap = require('./twin/gap'),
    TwinError = require('./twin/error')

/*
 * Twin Services: <Action on device> -> <Update Twin> /twin/*
 * API Services: <Action on device> -> <Send data to MBUS> /cassia/*
 * 
 */

// Open a connection and wait for a command
iotClient.open(err => {
    if (err) {
        console.error('could not open IotHub client')
    } else {
        console.log('Connected!')
    }

    iotClient.on('message', (msg) => {
        var incomingMsg = JSON.parse(msg.data)
        

        /*
         *  GAP Services
         */
        // Connection to device <API Service>
        if (incomingMsg.hasOwnProperty('makeconnection')) {
            if (incomingMsg.makeconnection.device) {
                CassiaGapServices.connect(incomingMsg.makeconnection.device.mac, (err, res) => {
                    if (err) {
                        TwinError.error('makeconnection', err)
                    } else {
                        // @TODO Chane from scanMessae attr
                        AzureMessage.send('scanMessage', res, (err, msgRes) => {
                            console.log(msgRes)
                        })
                    }
                })
            } else {
                TwinError.error('makeconnection', {"Error": "Missing a device to connect too."})
            }
        }

        // Disconnect from device <API Service>
        if (incomingMsg.hasOwnProperty('removeconnection')) {
            if (incomingMsg.removeconnection.device) {
                CassiaGapServices.disconnect(incomingMsg.removeconnection.device.mac, (err, res) => {
                    if (err) {
                        TwinError.error('removeconnection', err)  
                    } else {
                        // @TODO Chane from scanMessae attr
                        AzureMessage.send('scanMessage', res, (err, msgRes) => {
                            console.log(msgRes)
                        })
                    }
                })
            } else {
                TwinError.error('makeconnection', { "Error": "Missing a device to connect too." })
            }
        }

        // List of Connected devices <API Service>
        if (incomingMsg.hasOwnProperty('listconnected') && incomingMsg.listconnected == true) {
            CassiaGapServices.connected((err, res) => {
                if (err) {
                    TwinError.error('listconnected', err)
                } else {
                    // @TODO Chane from scanMessae attr
                    AzureMessage.send('scanMessage', res, (err, msgRes) => {
                        console.log(msgRes)
                    })
                }
            })
        }

        // Start Scanning
        if (incomingMsg.hasOwnProperty('scan') && incomingMsg.scan == true) {
            CassiaGapServices.scan(1, 1, (err, res) => {
                if (err) {
                    TwinError.error('scan', err)
                } else {
                    TwinGap.updateGap('scan', { "status": "Scanning" })
                }
            })
        }

        // Stop Scanning
        if (incomingMsg.hasOwnProperty('scan') && incomingMsg.scan == false) {
            CassiaGapServices.stopScan((err, res) => {
                if (err) {
                    TwinError.error('scanStop', err)
                } else {
                    TwinGap.updateGap('scan', { "status": "Stopped" })
                }
            })
        }

         /*
          *  GATT Services
          */
         // Discover GATT all services
        if (incomingMsg.hasOwnProperty('discoverallgattservices')) {
            if (incomingMsg.discoverallgattservices.device.mac) {
                CassiaGattServices.discoverAllServices(incomingMsg.discoverallgattservices.device.mac, (err, res) => {
                    if (err) {
                        TwinError.error('discoverallgattservices', err)
                    } else {
                        // @TODO Chane from scanMessae attr
                        AzureMessage.send('scanMessage', res, (err, msgRes) => {
                            console.log(msgRes)
                        })
                    }
                })
            } else {
                TwinError.error('discoverallgattservices', { "Error": "Missing a device to connect too." })
            }
        }

        // Discover GATT all characteristics
        if (incomingMsg.hasOwnProperty('discoverallgattcharacteristics')) {

            if (incomingMsg.discoverallgattcharacteristics.device.mac) {

                // Check for Service UUID
                if (incomingMsg.discoverallgattcharacteristics.device.serviceuuid) {
                    // Discover GATT all characteristics in service
                    CassiaGattServices.discoverAllCharacteristicsInService(incomingMsg.discoverallgattcharacteristics.device.mac, incomingMsg.discoverallgattcharacteristics.device.serviceuuid, (err, res) => {
                        if (error) {
                            TwinError.error('discoverallgattcharacteristics', err)
                        } else {
                            // @TODO Chane from scanMessae attr
                            AzureMessage.send('scanMessage', res, (err, msgRes) => {
                                console.log(msgRes)
                            })
                        }
                    })
                } else {
                    CassiaGattServices.discoverAllCharacteristics(incomingMsg.discoverallgattcharacteristics.device.mac, (err, res) => {
                        if (error) {
                            TwinError.error('discoverallgattcharacteristics', err)
                        } else {
                            // @TODO Chane from scanMessae attr
                            AzureMessage.send('scanMessage', res, (err, msgRes) => {
                                console.log(msgRes)
                            })
                        }
                    })
                }

            } else {
                TwinError.error('discoverallgattcharacteristics', { "Error": "Missing a device to connect too." })
            }
        }

        // Read Characteristic
        if (incomingMsg.hasOwnProperty('readCharacteristic')) {
            if (!incomingMsg.readCharacteristic.device) TwinError.error('readCharacteristic', { "Error": "Missing a device to connect too." })

            if (incomingMsg.readCharacteristic.device.mac && incomingMsg.readCharacteristic.device.characteristicHandle) {
                CassiaGattServices.readCharacteristic(incomingMsg.readCharacteristic.device.mac, incomingMsg.readCharacteristic.device.characteristicHandle, (err, res) => {
                    if (err) {
                        TwinError.error('readCharacteristic', err)
                    } else {
                        // @TODO Chane from scanMessae attr
                        AzureMessage.send('scanMessage', res, (err, msgRes) => {
                            console.log(msgRes)
                        })
                    }
                })
            }
        }

        // Write Characteristic
        if (incomingMsg.hasOwnProperty('writeCharacteristic')) {
            if (!incomingMsg.writeCharacteristic.device) TwinError.error('writeCharacteristic', { "Error": "Missing a device to connect too." })

            if (incomingMsg.writeCharacteristic.device.mac && incomingMsg.writeCharacteristic.device.characteristicHandle) {
                CassiaGattServices.writeCharacteristic(incomingMsg.writeCharacteristic.device.mac, incomingMsg.writeCharacteristic.device.characteristicHandle, incomingMsg.writeCharacteristic.device.characteristicValue, (err, res) => {
                    if (err) {
                        TwinError.error('writeCharacteristic', err)
                    } else {
                        // @TODO Chane from scanMessae attr
                        AzureMessage.send('scanMessage', res, (err, msgRes) => {
                            console.log(msgRes)
                        })
                    }
                })
            }
        }


        // Check for Restart <Twin Service>
        if (incomingMsg.hasOwnProperty('restart') && incomingMsg.restart == true) {
            TwinService.status("restart", (err, status) => {
                if (err) {
                    TwinError.error('restart', err)
                }
                // Do nothing for restart
            })
        }
    })

})
