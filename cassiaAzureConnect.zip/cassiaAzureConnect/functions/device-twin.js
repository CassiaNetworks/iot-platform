﻿// The Device Twin is a copy of all settings for this gateway just in the cloud.

let iotRegistry = require("../config/azure-registry"),
    AzureConfig = require('../config/azure-config.json')

// Get the device Twin
let getTwin = (callback) =>
{
    iotRegistry.getTwin(AzureConfig.deviceId, (err, twin) =>
    {
        //if (err) console.log(err)
        callback(err, twin)
    })
}

// Update the device twin with data
let updateTwin = (twinParams, callback) =>
{

    getTwin((err, twin) =>
    {
        iotRegistry.updateTwin(AzureConfig.deviceId, twinParams, twin.etag, (err, twin) => {
            callback(err, twin)
        })
    })

}


let twin = {
    getTwin: getTwin,
    updateTwin: updateTwin
}

module.exports = twin

