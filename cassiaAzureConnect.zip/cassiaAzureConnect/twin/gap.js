﻿let cassiaApiGap = require('../cassia/cassia-gap'),
    DeviceTwin = require('../functions/device-twin')

let twinUpdateObj = {
    properties: {
        desired: {
            gateway: {
                gap: {}
            }
        }
    }
}

let twinGapObj = {
    data: {
        timestamp: Date.now()
    }
}

let service = (options, callback) =>
{
    switch (options.gapService) {
        case "scan":
            cassiaApiGap.scan(options.scanType, options.duplicates, () => {
                
            })
            break;
        case "connected":
            cassiaApiGap.connected((err, res) => {
                callback(err, res)
            })
        default:
            break;
    }
}

let updateGap = (gapName, gapData) => {
    twinGapObj.data.gapName = gapName
    twinGapObj.data.gapData = gapData
    twinUpdateObj.properties.desired.gateway.gap = twinGapObj

    DeviceTwin.updateTwin(twinUpdateObj, (err, twin) => {
        if (err) console.log("Twin Update ERROR: " + err)
        return true
    })
}

let cassiaGap = {
    service: service,
    updateGap: updateGap
}

module.exports = cassiaGap
