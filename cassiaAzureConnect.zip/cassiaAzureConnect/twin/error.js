﻿let DeviceTwin = require('../functions/device-twin')

let twinUpdateObj = {
    properties: {
        desired: {
            gateway: {
            }
        }
    }
}

let twinErrorObj = {
    lastError: {
        errorOn: null,
        timestamp: Date.now(),
        errorData: null
    }
}

let error = (errorOn, errorData) => {

    twinErrorObj.lastError.errorOn = errorOn
    twinErrorObj.lastError.errorData = errorData

    twinUpdateObj.properties.desired.gateway = twinErrorObj

    DeviceTwin.updateTwin(twinUpdateObj, (err, twin) => {
        if (err) console.log("Twin Update ERROR: " + err)
        return true
    })
}

let twinError = {
    error: error
}

module.exports = twinError
