﻿let cassiaService = require('../cassia/cassia-service'),
    DeviceTwin = require('../functions/device-twin')


let twinUpdateObj = {
    properties: {
        desired: {
            gateway: {
            }
        }
    }
}

let status = (data, callback) =>
{
    switch (data) {
        case "restart":
            // Send to restart
            restart((err, res) => {
                callback(err, res)
            })
            break;

        default:
            break;
    }
}


// Private
let restart = (callback) =>
{
    // Let Device Twin know we are restarting
    twinUpdateObj.properties.desired.gateway = { status: "restarting" }
    DeviceTwin.updateTwin(twinUpdateObj, (err, twin) => {
        if (err) return callback(err, twin)
    })

    // Restart and callback null or error
    cassiaService.restart((err, res) => {
        callback(err, res)
    })
    
}

let gatewayService = {
    status: status
}

module.exports = gatewayService
