let EventSource = require('eventsource')

// This is a PM2 Service

let AzureMessage = require('../../functions/azure-message')

let es = new EventSource('http://10.10.10.254/gap/nodes?event=1&active=0&filter_duplicates=1')

es.addEventListener('message', function (e) {
    AzureMessage.send('scanMessage', e.data, (err, res) => {
        if (err) console.log(err)
    })
})
