let apiService = require('./apiService')

let discoverAllServices = (node, callback) => {
    apiService.sendRequest('/gatt/nodes/' + node + '/services?all=1', 'GET', null, (err, res) => {
        callback(err, res)
    })
}

let discoverAllCharacteristics = (node, callback) => {
    apiService.sendRequest('/gatt/nodes/' + node + '/characteristics?all=1', 'GET', null, (err, res) => {
        callback(err, res)
    })
}

let discoverAllCharacteristicsInService = (node, serviceUUID, callback) => {
    apiService.sendRequest('/gatt/nodes/' + node + '/services/' + serviceUUID + '/characteristics', 'GET', null, (err, res) => {
        callback(err, res)
    })
}

let readCharacteristic = (node, handle, callback) => {
    apiService.sendRequest('/gatt/nodes/' + node + '/handle/' + handle + '/value', 'GET', null, (err, res) => {
        callback(err, res)
    })
}

let writeCharacteristic = (node, handle, value, callback) => {
    apiService.sendRequest('/gatt/nodes/' + node + '/handle/' + handle + '/value/' + value, 'GET', null, (err, res) => {
        callback(err, res)
    })
}

let cassiaApiGatt = {
    discoverAllServices: discoverAllServices,
    discoverAllCharacteristics: discoverAllCharacteristics,
    discoverAllCharacteristicsInService: discoverAllCharacteristicsInService,
    readCharacteristic: readCharacteristic,
    writeCharacteristic: writeCharacteristic
}

module.exports = cassiaApiGatt
