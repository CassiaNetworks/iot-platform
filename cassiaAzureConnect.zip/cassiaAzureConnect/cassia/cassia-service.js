﻿let apiService = require('./apiService')

let restart = (callback) =>
{
    apiService.sendRequest('/cassia/reboot/', 'GET', null, (err, res) => {
        callback(err, res)
    })
}

let cassiaService = {
    restart: restart
}

module.exports = cassiaService
