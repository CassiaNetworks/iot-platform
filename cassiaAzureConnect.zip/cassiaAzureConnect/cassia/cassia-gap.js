﻿let pm2 = require('pm2')
//let EventSource = require('eventsource')

let apiService = require('./apiService'),
    AzureMessage = require('../functions/azure-message')

//let es = new EventSource('http://10.10.10.254/gap/nodes?event=1&active=0&filter_duplicates=1')

let scan = (scanType, duplicates, callback) => {
    pm2.connect(err => {
        if (err) {
            console.error(err)
            process.exit(2)
            callback(err, false)
        }

        pm2.start({
            script: '/home/cassia/cassiaAzureConnect/cassia/services/scan.js'
        }, (err, app) => {
            pm2.disconnect()
        })
    })

    callback(null, true)

    //es.addEventListener('message', function (e) {
    //    AzureMessage.send('scanMessage', e.data, (err, res) => {
    //        if (err) console.log(err)
    //    })
    //})
}

let stopScan = (callback) => {
    //es.close()
    pm2.stop('scan', err => {
        console.error(err)
    })
    callback(null, true)
}

let connected = (callback) => {
    apiService.sendRequest('/gap/nodes?connection_state=connected', 'GET', null, (err, res) => {
        callback(err, res)
    })
}

let connect = (node, callback) => {
    apiService.sendRequest('/gap/nodes/' + node + '/connection', 'POST', null, (err, res) => {
        callback(err, res)
    })
}

let disconnect = (node, callback) => {
    apiService.sendRequest('/gap/nodes/' + node + '/connection', 'DELETE', null, (err, res) => {
        callback(err, res)
    })
}

let cassiaApiGap = {
    scan: scan,
    stopScan: stopScan,
    connected: connected,
    connect: connect,
    disconnect: disconnect
}

module.exports = cassiaApiGap
