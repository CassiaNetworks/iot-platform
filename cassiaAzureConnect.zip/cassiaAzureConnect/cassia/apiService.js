﻿let DeviceConfig = require("../config/device-config.json")

let request = require('request')

let requestOptions = {
    headers: {
        'Accept': 'application/json'
    }
}

let sendRequest = (uri, method, options = null, callback) =>
{
    requestOptions.url = DeviceConfig.api.host + uri
    requestOptions.method = method

    // Check for additional options
    if (options) {
        // Append Options
    }

    request(requestOptions, (err, res, body) => {
        callback(err, body)
    })
}

let apiService = {
    sendRequest: sendRequest
}

module.exports = apiService

