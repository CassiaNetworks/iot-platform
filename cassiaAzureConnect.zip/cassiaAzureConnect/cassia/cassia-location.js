﻿let cassiaApiService = require('./apiService')

let gatewaySees = (callback) => {
    cassiaApiService.sendRequest('/middleware/position/by-ap/', 'GET', null, (err, res) => {
        callback(err, res)
    })
}

let cassiaApiLocation = {
    gatewaySees: gatewaySees
}

module.exports = cassiaApiLocation
