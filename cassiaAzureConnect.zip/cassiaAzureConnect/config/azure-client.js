﻿let Client = require('azure-iot-device').Client,
    Protocol = require('azure-iot-device-mqtt').Mqtt

let AzureConfig = require('./azure-config.json')

let connectionString = AzureConfig.connectionString

let client = Client.fromConnectionString(AzureConfig.clientString, Protocol)


module.exports = client
