﻿let Registry = require('azure-iothub').Registry

let AzureConfig = require('./azure-config.json')

let connectionString = AzureConfig.connectionString,
    deviceId = AzureConfig.deviceId

let registry = Registry.fromConnectionString(connectionString);

module.exports = registry
